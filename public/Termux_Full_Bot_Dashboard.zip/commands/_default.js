/*CMD
  command: _default
  help: الموجه الذكي للرسائل الافتراضية وحارس الأزرار والتعليقات V4.0
  need_reply: false
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: *
CMD*/

// 1. فحص هل الرسالة تعليق في مجموعة المناقشة التابعة للقناة
if (typeof request !== "undefined" && request && request.message) {
  var msg = request.message;
  if (msg.chat && (msg.chat.type === "supergroup" || msg.chat.type === "group")) {
    if (msg.reply_to_message) {
      Bot.runCommand("/handle_comment");
      return;
    }
  }
}

var raw_text = (typeof message !== "undefined" && message) ? message.trim() : "";

// 2. فحص وتوجيه نصوص أزرار الكيبورد بدقة فورية
if (raw_text) {
  var t = raw_text;

  // أزرار إدارة الجامعات وقنوات النشر
  if (t === "🏛️ إدارة الجامعات والمصادر" || t === "🏛️ إدارة الجامعات وقنوات النشر" || t === "🏛️ الجامعات وقنواتها" || t === "إدارة الجامعات" || t === "الجامعات" || t === "/universities" || t === "/univ") {
    Bot.runCommand("/universities");
    return;
  }

  // معالج ربط جامعة وقناة (5 خطوات)
  if (t === "➕ معالج ربط جامعة وقناة (5 خطوات)" || t === "➕ معالج ربط جامعة وقناة" || t === "➕ إضافة جامعة وقناة نشر" || t === "➕ إضافة جامعة جديدة" || t === "إضافة جامعة" || t === "/add_university" || t === "/new_univ") {
    Bot.runCommand("/add_university");
    return;
  }

  // فحص وسحب الأخبار
  if (t === "🔄 فحص وسحب الأخبار فوراً" || t === "🔄 فحص وسحب أخبار الجامعات" || t === "🔄 فحص وسحب الأخبار" || t === "سحب المنشورات" || t === "فحص المصادر" || t === "/crawl_sources" || t === "/crawl") {
    Bot.runCommand("/crawl_sources");
    return;
  }

  // بحث أخبار جوجل
  if (t === "🌐 بحث أخبار جوجل الأكاديمية" || t === "🌐 بحث أخبار جوجل للجامعة" || t === "🌐 أخبار جوجل" || t === "أخبار جوجل" || t === "بحث جوجل نيوز" || t === "/google_news" || t === "/gnews") {
    Bot.runCommand("/google_news");
    return;
  }

  // صياغة ونشر خبر فوري
  if (t === "📝 صياغة ونشر خبر فوري" || t === "📝 صياغة ونشر فوري" || t === "صياغة ونشر خبر" || t === "نشر خبر" || t === "/new_post") {
    Bot.runCommand("/new_post");
    return;
  }

  // إعلان خدماتي البديل
  if (t === "🎯 إعلان خدماتي البديل" || t === "إعلان خدماتي" || t === "الإعلان البديل" || t === "/ad") {
    Bot.runCommand("/ad");
    return;
  }

  // إعدادات الذكاء الاصطناعي
  if (t === "⚙️ إعدادات الذكاء الاصطناعي" || t === "⚙️ إعدادات الذكاء" || t === "إعدادات الذكاء" || t === "الذكاء الاصطناعي" || t === "/ai") {
    Bot.runCommand("/ai");
    return;
  }

  // محادثة وبحث الذكاء
  if (t === "💬 محادثة وبحث الذكاء" || t === "محادثة وبحث الذكاء" || t === "💬 محادثة الذكاء" || t === "محادثة الذكاء" || t === "/chat") {
    Bot.runCommand("/chat");
    return;
  }

  // مفاتيح API والاعتمادات
  if (t === "🔑 مفاتيح API والاعتمادات" || t === "مفاتيح API" || t === "المفاتيح" || t === "/keys") {
    Bot.runCommand("/keys");
    return;
  }

  // إدارة اليوزربوت وجلسة الحساب
  if (t === "👤 إدارة اليوزربوت وجلسة الحساب" || t === "👤 إدارة اليوزربوت" || t === "إدارة اليوزربوت" || t === "اليوزربوت" || t === "/userbot") {
    Bot.runCommand("/userbot");
    return;
  }

  // تعليمات المحرر الأكاديمي
  if (t === "📝 تعليمات المحرر الأكاديمي" || t === "تعليمات المحرر الأكاديمي" || t === "تعليمات المحرر" || t === "/instructions") {
    Bot.runCommand("/instructions");
    return;
  }

  // تجربة الصياغة الفورية
  if (t === "🧪 تجربة الصياغة الفورية" || t === "تجربة الصياغة" || t === "/test") {
    Bot.runCommand("/test");
    return;
  }

  // حالة النظام والتقارير
  if (t === "📊 حالة النظام والتقارير" || t === "حالة النظام" || t === "تقارير النشر" || t === "/status") {
    Bot.runCommand("/status");
    return;
  }

  // تشغيل / إيقاف البوت
  if (t === "🟢 تشغيل / إيقاف البوت" || t === "تشغيل / إيقاف البوت" || t === "إيقاف مؤقت" || t === "/pause") {
    Bot.runCommand("/pause");
    return;
  }

  // الدعم الفني والمساعدة
  if (t.indexOf("الدعم الفني") !== -1 || t.indexOf("المشرف") !== -1 || t.indexOf("M_S_F_G") !== -1 || t === "/support" || t === "/help") {
    Bot.runCommand("/support");
    return;
  }

  // قنواتنا وروابط التواصل
  if (t === "🌐 قنواتنا وروابط التواصل" || t === "روابط التواصل" || t === "قنواتنا" || t === "/social") {
    Bot.runCommand("/social");
    return;
  }

  // الأوامر الأساسية الشائعة
  if (t === "🎛 لوحة التحكم الرئيسية" || t === "لوحة التحكم" || t === "الرئيسية" || t === "/start" || t === "/menu") {
    Bot.runCommand("/start");
    return;
  }

  // الكلمات الترحيبية القصيرة
  var greetings = ["مرحبا", "سلام", "الو", "هلا", "hi", "hello", "سلام عليكم", "السلام عليكم"];
  if (greetings.indexOf(t.toLowerCase()) !== -1) {
    Bot.sendMessage("👋 أهلاً بك يا مديرنا العزيز!\nوجّه أي منشور أو أرسل خبراً كاملاً لإعادة صياغته ونشره، أو اختر من القائمة أدناه:");
    Bot.runCommand("/start");
    return;
  }
}

// 3. إذا لم يكن أمراً، وكان في محادثة خاصة أو موجهاً، يحول لمعالج المنشورات
Bot.runCommand("handle_user_post");
